class DIM:
    wheel_sep = 0.28
    wheel_rad = 0.07